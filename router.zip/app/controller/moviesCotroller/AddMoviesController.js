const AddMoviesController = async (req, res) => {};

module.exports = AddMoviesController;
